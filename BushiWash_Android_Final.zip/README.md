# Bushi Wash Android

Aplicativo Android da Bushi Wash Estética Automotiva, com a interface de gestão embarcada em WebView e dados locais no aparelho.

## Funcionalidades
- Dashboard de faturamento, custos e lucro líquido estimado
- Clientes com WhatsApp, endereço, veículo e observações
- Serviços e preços editáveis
- Produtos e estoque
- Novo atendimento com entrada, custos e forma de pagamento
- Financeiro, pendências e backup/restauração em JSON
- Funcionamento local, sem servidor obrigatório

## Gerar o APK
Este projeto usa Android Gradle Plugin 8.8.2, compileSdk 35 e minSdk 23.
Abra no Android Studio ou em um ambiente Android/Gradle na nuvem e execute `assembleDebug`.
O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observação
O APK não foi pré-compilado neste pacote porque a máquina de preparação não possui o Android SDK/aapt2/d8/apksigner. O código-fonte está pronto para compilação em um ambiente Android.
