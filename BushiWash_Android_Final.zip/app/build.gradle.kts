plugins { id("com.android.application") }

android { namespace = "com.bushiwash.app"; compileSdk = 35
    defaultConfig { applicationId = "com.bushiwash.app"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
